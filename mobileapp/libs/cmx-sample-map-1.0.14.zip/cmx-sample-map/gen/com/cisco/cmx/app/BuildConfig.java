/** Automatically generated file. DO NOT MODIFY */
package com.cisco.cmx.app;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}